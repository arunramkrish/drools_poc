package com.connecture.bigbear.ancillary.test.data;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.connecture.bigbear.ancillary.constants.Flag;
import com.connecture.bigbear.ancillary.constants.RelationShip;
import com.connecture.bigbear.ancillary.json.util.Json2Pojo;
import com.connecture.bigbear.ancillary.json.util.JsonReader;
import com.connecture.bigbear.ancillary.model.Coverage;
import com.connecture.bigbear.ancillary.model.Eligibility;
import com.connecture.bigbear.ancillary.model.Member;
import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.model.PlanDetail;
import com.connecture.bigbear.ancillary.model.Profile;
import com.connecture.bigbear.ancillary.model.State;

public class TestData {

	private static final String BASE_JSON_DIR = "json/generated/";
	public static Set<Profile> getProfileObject() {
		String jsonPath = BASE_JSON_DIR + "/profile.json";
		String content = JsonReader.readJsonContentFromClassPath(jsonPath) ;
		return Json2Pojo.getProfile(content);
	} 
	public static Set<Plan> getPlansObject() {
		String jsonPath = BASE_JSON_DIR + "/plans.json";
		String content = JsonReader.readJsonContentFromClassPath(jsonPath);
		return Json2Pojo.getPlan(content);
	} 	
	public static Set<Plan> findPlans() {
		State ca = new State();
		ca.setCode("CA");
		ca.setName("CA");
		State ny = new State();
		ny.setCode("NY");
		ny.setName("NY");
		List<State> states = Arrays.asList(ca ,ny);
		List<String> zip1 = Arrays.asList("00001");
		List<String> zip2 = Arrays.asList("00001", "00002");
		List<String> zip3 = Arrays.asList("00001", "00002", "00003");
		List<String> zip4 = Arrays.asList("00001", "00002", "00003", "00004");
		
		Set<Plan> list = new HashSet<Plan>();
			Plan plan1 = new Plan();
				plan1.setProvider("AETNA");
				PlanDetail detail1 = new PlanDetail();
				detail1.setId("AEVB007");
				detail1.setTitle("Vision Basic");
				detail1.setDeductible("100");
					Eligibility e1 = new Eligibility();
						e1.setSmoking(Flag.Yes.name());
						e1.setMinAge(25);
						e1.setMaxAge(59);
						e1.setStates(states);
						e1.setZipCodes(zip1);
					Coverage coverage1 = new Coverage();
						coverage1.setCoPay("80");
						coverage1.setFrames("12");
						coverage1.setLenses("12");
				detail1.setCoverage(coverage1);
				detail1.setEligibility(e1); 
			plan1.setDetail(detail1 );
		list.add(plan1);
		
		
		Plan plan2 = new Plan();
			plan2.setProvider("UNITED");
			PlanDetail detail2 = new PlanDetail();
				detail2.setId("UNVE027");
				detail2.setTitle("Vision Elite");
				detail2.setDeductible("200");
				Eligibility e2 = new Eligibility();
					e2.setSmoking(Flag.Yes.name());
					e2.setMinAge(5);
					e2.setMaxAge(65);
					e2.setStates(states);
					e2.setZipCodes(zip2);
				Coverage coverage2 = new Coverage();
					coverage2.setCoPay("80");
					coverage2.setFrames("12");
					coverage2.setLenses("12");
				detail2.setCoverage(coverage2 );
				detail2.setEligibility(e2);
				plan2.setDetail(detail2 );
		list.add(plan2);
				
		Plan plan3 = new Plan();
			plan3.setProvider("UNITED");
			PlanDetail detail3 = new PlanDetail();
				detail3.setId("UNDE057");
				detail3.setTitle("Dental Elite");
				detail3.setDeductible("100");
			Eligibility e3 = new Eligibility();
				e3.setSmoking(Flag.No.name());
				e3.setMinAge(25);
				e3.setMaxAge(64);
				e3.setStates(states);
				e3.setZipCodes(zip3);
			Coverage coverage3 = new Coverage();
				coverage3.setCoPay("80");
				coverage3.setFrames("12");
				coverage3.setLenses("12");
				coverage3.setVeneers("50");
				coverage3.setXrays("12");
			detail3.setCoverage(coverage3 );
			detail3.setEligibility(e3);
		plan3.setDetail(detail3 );
		list.add(plan3);
		
		Plan plan4 = new Plan();
			plan4.setProvider("MET LIFE");
			PlanDetail detail4 = new PlanDetail();
				detail4.setId("MLDB067");
				detail4.setTitle("Dental Basic");
				detail4.setDeductible("200");
				Eligibility e4 = new Eligibility();
					e4.setSmoking(Flag.No.name());
					e4.setMinAge(25);
					e4.setMaxAge(64);
					e4.setStates(states);
					e4.setZipCodes(zip4);
				Coverage coverage4 = new Coverage();
					coverage4.setCoPay("80");
					coverage4.setFrames("12");
					coverage4.setLenses("12");
					coverage4.setVeneers("50");
					coverage4.setXrays("12");
				detail4.setCoverage(coverage4 );
				detail4.setEligibility(e4);
		plan4.setDetail(detail4);
		list.add(plan4);
		return list; 	
	}

	public static  Profile getProfile() { 
		Profile p = new Profile();
		p.setZipCode("88888");
		p.setEligibleForTax(Flag.Yes.name());
		p.setMedicalCoverageExists(Flag.No.name());
		Set<Member> members = new HashSet<Member>();
		Member m=new Member();
		m.setName("TIM");
		m.setAdult(true);
		Calendar cal = Calendar.getInstance();
		cal.set(1985, 12, 16);
		m.setDateOfBirth(cal.getTime());
		m.setRelationShip(RelationShip.Primary.name());
		m.setSmoking(Flag.Yes.name());
		members.add(m);
		Member m2=new Member();
		m2.setName("TIMA");
		m2.setAdult(false);
		cal.set(1974, 02,01);
		m2.setDateOfBirth(cal.getTime());
		m2.setRelationShip(RelationShip.Spouse.name());
		m2.setSmoking(Flag.No.name());
		members.add(m2);
		
		Member m3=new Member();
		m3.setName("MIMA");
		m3.setAdult(false);
		cal.set(2012, 02,01);
		m3.setDateOfBirth(cal.getTime());
		m3.setRelationShip(RelationShip.Spouse.name());
		m3.setSmoking(Flag.No.name());
		members.add(m3);
		p.setMembers(members );
		
		return p;
	}
}
