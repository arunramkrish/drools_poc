package com.connecture.bigbear.ancillary.test;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.connecture.bigbear.ancillary.shop.web.EligibilityRestController;

@RunWith(MockitoJUnitRunner.class)
public class EligibilityWebClient {
	 @Mock
	 EligibilityRestController rest;
	 
	 @Before
	 public void setUp() {
	    rest = new EligibilityRestController();
	 }
	 
	 @Test
	  public void shouldFetchProfile() throws Exception {
	        rest.profile();
	    }
 }
