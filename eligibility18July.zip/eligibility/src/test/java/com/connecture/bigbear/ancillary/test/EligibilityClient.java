package com.connecture.bigbear.ancillary.test;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.connecture.bigbear.ancillary.constants.Flag;
import com.connecture.bigbear.ancillary.model.Member;
import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.model.Profile;
import com.connecture.bigbear.ancillary.shop.AbstractEligibilityService;
import com.connecture.bigbear.ancillary.shop.StatelessEligibilityService;
import com.connecture.bigbear.ancillary.test.data.TestData;
import com.connecture.bigbear.ancillary.util.LogHandler;
import com.connecture.bigbear.ancillary.util.LogUtil;
public class EligibilityClient {  
	private static LogHandler log = LogHandler.get(EligibilityClient.class);
	private Set<Profile> profiles = TestData.getProfileObject(); 
	Set<Plan> plans = TestData.getPlansObject();
	@Test
	public void doShop() { 
		log.view("<Available Plans> Below:");
		LogUtil.print(plans); 
		log.view("<Results> Below:"); 
		doShop(new StatelessEligibilityService(),false);
		/*
		  perform(new StatefulShop(),false); 
		  doShop(new StatelessShop(),true);
		  perform(new StatefulShop(),true);
		*/ 
	}
	
	public void doShop(AbstractEligibilityService s, boolean multiple) { 
		log.info("@perform Shopping <"+s.getClass().getSimpleName()+"> Multiple Rule Files?"+multiple); 
		Object[]facts = null; 
		Profile profile = null;
		Set<Plan> recommended = null;
		
		for (Iterator<Profile> iterator = profiles.iterator(); iterator.hasNext();) {
			profile = (Profile) iterator.next();
			plans = TestData.getPlansObject(); // If not, filtering previous results
			facts = new Object[]{profile,plans};
			s.execute(facts,multiple);			
			recommended = new HashSet<Plan>();
			buildResult(s,recommended);
			profile.setRecommendedPlans(recommended); 
			log.view("\n\n================================================"); 
			//log.view(profile.toString());
			LogUtil.print(recommended); 
			assertResult(profile,recommended);
			//ThreadUtil.sleepQuietly(1000);
		}  
		
	}

	private void assertResult(Profile profile, Set<Plan> recommended) {
		boolean flag = hasSmoker(profile.getMembers());
		 
		 if(profile.getZipCode().equals("00001") && flag){
			 Assert.assertEquals(5, recommended.size());
		 } else if(profile.getZipCode().equals("00001")){
			 Assert.assertEquals(7, recommended.size());
		 }
		 if(profile.getZipCode().equals("00002") && flag){
			 Assert.assertEquals(4, recommended.size());
		 } else if(profile.getZipCode().equals("00002") ){
			 Assert.assertEquals(6, recommended.size());
		 }
		 		 
		 if(profile.getZipCode().equals("00003") && flag){
			 Assert.assertEquals(2, recommended.size());
		 } else if(profile.getZipCode().equals("00003") ){
			 Assert.assertEquals(5, recommended.size());
		 }
		 
		 if(profile.getZipCode().equals("00004") && flag){
			 Assert.assertEquals(0, recommended.size());
		 } else if(profile.getZipCode().equals("00004") ){
			 Assert.assertEquals(1, recommended.size());
		 }
		 
		 if(profile.getZipCode().equals("55555") && flag){
			 Assert.assertEquals(0, recommended.size());
		 } else if(profile.getZipCode().equals("55555") ){
			 Assert.assertEquals(0, recommended.size());
		 }
	}

	private boolean hasSmoker(Set<Member> members) {
		 for (Iterator<Member> iterator = members.iterator(); iterator.hasNext();) {
			Member member = (Member) iterator.next();
			if(Flag.Yes.name().equals(member.getSmoking())){
				return true;
			}
		}
		 return false;
	}

	private void buildResult(AbstractEligibilityService s, Set<Plan> recommended) {
		Map<Plan,String> resultMap = s.getPlanMap();
		Set<Plan> keys= resultMap.keySet();

		for (Iterator<Plan> iterator2 = keys.iterator(); iterator2.hasNext();) {
			Plan plan = (Plan) iterator2.next();
			String value = resultMap.get(plan);
			if(value!=null && value.startsWith("NO_MATCH"))
			{
				//log.view("Plan: "+plan+": "+value);
			} else {
				recommended.add(plan);
			}
		}
		
	}	
}