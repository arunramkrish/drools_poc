package com.connecture.bigbear.ancillary.rules.process;

import java.util.HashMap;
import java.util.Map;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;

import com.connecture.bigbear.ancillary.exception.EligibilityException;

public class StatefulRuleExecutor extends RuleExecutor{
	private String[]agenda;
	
	public StatefulRuleExecutor(String[]agenda,String sessionName) {
		this.agenda = agenda;
		super.sessionName = sessionName;
	}
	public void execute(Object[]facts) throws EligibilityException {
		KieSession ksession=null;
		try {
			ksession = getStatefulSession(sessionName);   
			FactHandle[] factHandles = new FactHandle[facts.length] ;
			for (int i = 0; i < facts.length; i++) {
				factHandles[i] = ksession.insert(facts[i]);
			}
			for (int i = 0; i < agenda.length; i++) { 
				ksession.getAgenda().getAgendaGroup(agenda[i]).setFocus();
			}  
			for(String key:getGlobal().keySet()){
				ksession.setGlobal(key,getGlobal().get(key));
			} 
			ksession.addEventListener(new CommonAgendaEventListener());
			int n = ksession.fireAllRules();
			log.info("@StatefulRuleExecutor No of Rules Fired:"+n);
			Map<String,Object> result = new HashMap<String, Object>();
			for(String key:ksession.getGlobals().getGlobalKeys() ){
				result.put(key,ksession.getGlobals().get(key));
			} 
			setResult(result);
			log.info("Results:"+result);
			for (int i = 0; i < factHandles.length; i++) {
				log.info("@StatefulRuleExecutor Delete:"+factHandles[i].toExternalForm());
				ksession.delete(factHandles[i]);	
			}
		} catch (Exception e) { 
			log.error("@StatefulRuleExecutor execute Exception",e);
			throw new EligibilityException(e);
		} finally{
			ksession.dispose();
		}
	}
}
