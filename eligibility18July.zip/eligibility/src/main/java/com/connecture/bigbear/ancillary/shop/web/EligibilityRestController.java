package com.connecture.bigbear.ancillary.shop.web;

import java.util.Set;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.connecture.bigbear.ancillary.exception.EligibilityException;
import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.model.Profile;
import com.connecture.bigbear.ancillary.shop.StatelessEligibilityService;
import com.connecture.bigbear.ancillary.test.data.TestData;
import com.connecture.bigbear.ancillary.util.LogHandler;

@RestController
@EnableAutoConfiguration
@RequestMapping("/")
public class EligibilityRestController {
	private static final LogHandler log = LogHandler.get(EligibilityRestController.class);
	  
	@RequestMapping(value = "/profile/", 
			method = RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Profile profile() {
		Profile profile = TestData.getProfile();
		return profile;
	}

	@RequestMapping(value = "/plans/", 
			method = RequestMethod.POST,
			produces=MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Set<Plan> plans(
	@RequestBody Profile profile){
		 log.view("ShopController prints String value:"+profile);
		 Object[] facts = null;
			Set<Plan> recommended = null;
			Set<Plan> plans = TestData.getPlansObject();
			StatelessEligibilityService s = new StatelessEligibilityService();
			facts = new Object[] { profile, plans };
			s.execute(facts, false);
			recommended = s.extractResult(); 
			if(recommended==null || recommended.size()==0){
				throw new EligibilityException("No Plans for given demographics");
			}
			profile.setRecommendedPlans(recommended);
			return recommended;
	}
}
