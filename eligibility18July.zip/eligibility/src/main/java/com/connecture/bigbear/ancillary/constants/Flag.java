package com.connecture.bigbear.ancillary.constants;

public enum Flag {
	Yes,No,NotSure
}
