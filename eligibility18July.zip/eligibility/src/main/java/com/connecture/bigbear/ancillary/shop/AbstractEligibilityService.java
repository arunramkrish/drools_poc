package com.connecture.bigbear.ancillary.shop;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.rules.process.RuleExecutor;
import com.connecture.bigbear.ancillary.util.LogHandler;
public abstract class AbstractEligibilityService {  
	private RuleExecutor executor ;
	protected static LogHandler log = LogHandler.get(AbstractEligibilityService.class); 
	private Map<String,Object> global;
    private Map<Plan,String> planMap;
	protected abstract void doExecute(Object[]facts, boolean multiple);
	  
	public Map<String,Object> getGlobal() {
		return global;
	}

	public void setGlobal(Map<String,Object> global) {
		this.global = global;
	}
	
	@SuppressWarnings("unchecked")
	public final void execute(Object[]facts, boolean multiple) {
		final String RecommendedPlans = "RecommendedPlans";
		Map<String, Object> global = new HashMap<String, Object>();
		global.put("log", log);
		global.put(RecommendedPlans, new HashMap<Plan,String>());
		setGlobal(global);
		doExecute(facts, multiple);
		if(getExecutor().getResult()!=null)
		{
			setPlanMap((Map<Plan,String>) getExecutor().getResult().get(RecommendedPlans)); 
		}
	}
	public Set<Plan> extractResult() {
		Set<Plan> recommended = new HashSet<Plan>();
		Map<Plan, String> resultMap = getPlanMap();
		Set<Plan> keys = resultMap.keySet();
		for (Iterator<Plan> iterator2 = keys.iterator(); iterator2.hasNext();) {
			Plan plan = (Plan) iterator2.next();
			String value = resultMap.get(plan);
			if (value != null && value.startsWith("NO_MATCH")) {
				// log.view("Plan: "+plan+": "+value);
			} else {
				recommended.add(plan);
			}
		}
		return recommended;
	}

	public RuleExecutor getExecutor() {
		return executor;
	}

	public void setExecutor(RuleExecutor executor) {
		this.executor = executor;
	}

	public Map<Plan,String> getPlanMap() {
		return planMap;
	}

	public void setPlanMap(Map<Plan,String> planMap) {
		this.planMap = planMap;
	}

}