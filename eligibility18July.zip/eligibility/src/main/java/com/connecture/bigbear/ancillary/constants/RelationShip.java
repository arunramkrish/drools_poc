package com.connecture.bigbear.ancillary.constants;

public enum RelationShip {
	Primary,Spouse,Child1,Child2
}
