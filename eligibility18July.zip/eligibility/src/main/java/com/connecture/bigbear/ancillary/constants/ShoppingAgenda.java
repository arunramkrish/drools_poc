package com.connecture.bigbear.ancillary.constants;

public enum ShoppingAgenda {
	ZipNoMatch,
	AgeRangeNoMatch,
	TobaccoHabitNoMatch,
	TobaccoHabitCoverage,
	AddRecommendedPlans;
	
	/**
	 * @return list of agenda as string array
	 */
	public static String[] names() {
		ShoppingAgenda[] agenda = values();
	    String[] names = new String[agenda.length];

	    for (int i = 0; i < agenda.length; i++) {
	        names[i] = agenda[i].name();
	    }

	    return names;
	}
}
