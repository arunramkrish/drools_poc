package com.connecture.bigbear.ancillary.exception;

public class EligibilityException extends RuntimeException{
 
	private static final long serialVersionUID = 4028519366397778797L;
	
	public EligibilityException(String s) {
		 super(s);
	}
	public EligibilityException(Throwable t) {
		 super(t);
	}
	 
}
