package com.connecture.bigbear.ancillary.model;

import java.util.List;

public class Eligibility {
	private int minAge;
	private int maxAge;
	private List<State> states;
	private List<String> zipCodes;
	private String smoking;
	
	public int getMinAge() {
		return minAge;
	}
	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}
	public List<State> getStates() {
		return states;
	}
	public void setStates(List<State> states) {
		this.states = states;
	}
	public List<String> getZipCodes() {
		return zipCodes;
	}
	public void setZipCodes(List<String> zipCodes) {
		this.zipCodes = zipCodes;
	}
	public String getSmoking() {
		return smoking;
	}
	public void setSmoking(String smoking) {
		this.smoking = smoking;
	} 
	 
	public int getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[<Min Age:").append(minAge).append(";")
		.append("Max Age:").append(maxAge).append(";")
		.append("States:").append(states).append(";")
		.append("Zipcodes:").append(zipCodes).append(";")
		.append("Smoking:").append(smoking).append(";").append("]"); 
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Eligibility)){
			return false;
		}
		Eligibility e = (Eligibility)obj;
		boolean isEqual = (this.minAge == e.getMinAge());
		isEqual = isEqual && (this.maxAge == e.getMaxAge());;
		isEqual = isEqual && this.states.equals(e.getStates());
		isEqual = isEqual && this.zipCodes.equals(e.getZipCodes());
		isEqual = isEqual && this.smoking.equals(e.getSmoking()); 
		 
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31;
		r *= this.minAge;
		r *= this.maxAge;
		r *= this.states.hashCode();
		r *= this.zipCodes.hashCode();
		r *= this.smoking.hashCode(); 
		return r;
	}
}
