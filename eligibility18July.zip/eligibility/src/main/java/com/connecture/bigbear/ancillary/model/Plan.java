package com.connecture.bigbear.ancillary.model;

public class Plan {
	private String provider;
	private PlanDetail detail;
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public PlanDetail getDetail() {
		return detail;
	}
	public void setDetail(PlanDetail detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[<Provider:").append(provider).append(";")
		.append("Detail:").append(detail).append(";").append("]");
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Plan)){
			return false;
		}
		Plan c=(Plan)obj;
		boolean isEqual = this.provider == c.getProvider();
		isEqual = this.provider == c.getProvider();
		if(!isEqual)
		{
			isEqual = this.provider.equals(c.getProvider());
			isEqual = isEqual && this.detail.equals(c.getDetail());
		}
		 
		return isEqual;
	}
	@Override
	public int hashCode() {
		 
		int r = 31;
		r *= this.provider.hashCode();
		r *= (this.detail==null?1:this.detail.hashCode());
		 
		return r;
	}
}
