package com.connecture.bigbear.ancillary.rules.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kie.api.command.Command;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.internal.command.CommandFactory;

import com.connecture.bigbear.ancillary.exception.EligibilityException;

public class StatelessRuleExecutor extends RuleExecutor{ 
	
	public StatelessRuleExecutor(String sessionName) {
		super.sessionName = sessionName; 
	}
	@SuppressWarnings("rawtypes")
	@Override
	public void execute(Object[] facts) throws EligibilityException {
		StatelessKieSession ksession =null;
		try {
			ksession = getStateLess(sessionName); 
		 
			List<Command> cmds = new ArrayList<Command>();
			
			for (int i = 0; i < facts.length; i++) {
				  cmds.add( CommandFactory.newInsert(facts[i]) );
			}
			
			for(String key:getGlobal().keySet()){ 
				 //cmds.add( CommandFactory.newSetGlobal(key,getGlobal().get(key))); //Not Working use session.setGlobal
				 ksession.setGlobal(key, getGlobal().get(key));
			}  
			cmds.add( CommandFactory.newFireAllRules());
			
			 //No agenda for State-less, works based on salience
			 //ksession.addEventListener(new ShoppingAgendaEventListener());
			ExecutionResults  er = ksession.execute( CommandFactory.newBatchExecution( cmds ) );
			log.info("ExecutionResults"+er);
			Map<String,Object> result = new HashMap<String, Object>();
			for(String key:ksession.getGlobals().getGlobalKeys() ){
				result.put(key,ksession.getGlobals().get(key)); 
			} 
			setResult(result);
			 
			log.info("Results:"+result);
		} catch (Exception e) {
			log.error("@StatelessRuleExecutor execute Exception",e);
			throw new EligibilityException(e);
		} finally{
			// Cleanup
		}
	}
	 
	
	 
}
