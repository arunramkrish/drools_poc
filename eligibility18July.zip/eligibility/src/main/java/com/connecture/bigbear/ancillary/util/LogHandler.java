package com.connecture.bigbear.ancillary.util;

import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LogHandler {
	private boolean INFO_ENABLED =false;
	private Logger logger = null;
	private static final String LOG4J_PATH = "config/log4j.properties";
	private LogHandler(Logger l) {
		this.logger = l;
	}
	public static LogHandler get(Class<?> clz){
		URL configUrl = clz.getClassLoader().getResource(LOG4J_PATH);
		PropertyConfigurator.configure(configUrl );
		Logger l = Logger.getLogger(clz);	
		return new LogHandler(l);
	}
	public void view(String m) {
		logger.info(m);
	}
	public void info(String m) {
		if(INFO_ENABLED){
			logger.info(m);
		}
		
	}
	public void info(String m, Throwable t){
		logger.info(m, t);
	}
	public void debug(String m) {
		logger.debug(m);
	}
	public void debug(String m, Throwable t){
		logger.debug(m, t);
	}
	public void warn(String m){
		logger.warn(m);
	}
	public void warn(String m, Throwable t){
		logger.warn(m, t);
	}
	public void error(String m){
		logger.error(m);
	}
	public void error(String m, Throwable t){
		logger.error(m, t);
	}
	public void fatal(String m){
		logger.fatal(m);
	}
	public void fatal(String m, Throwable t){
		logger.fatal(m, t);
	}
	 
}
