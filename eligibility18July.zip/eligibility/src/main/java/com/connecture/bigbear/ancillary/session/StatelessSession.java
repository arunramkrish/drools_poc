package com.connecture.bigbear.ancillary.session;

import org.kie.api.runtime.StatelessKieSession;

public class StatelessSession extends BaseSession{
	private StatelessKieSession kSession =null;
	//Need to analyze if this is thread-safe, if required, implement ThreadLocal
	public StatelessKieSession getStateLess() {
	 kSession = kContainer.newStatelessKieSession();
	 kContainer.verify();
	 log.info("@getStateLess Return ");
	 return kSession; 
	}
	public StatelessKieSession getStateLess(String name) {
	 kSession = kContainer.newStatelessKieSession(name);
	 kContainer.verify();
	 log.info("@getStateLess Return :"+name);
	 return kSession; 
	}
	 
	public static void clean() {
		//TODO no dispose in state-less session.. need to analyze 
	}
}
