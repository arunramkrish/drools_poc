package com.connecture.bigbear.ancillary.shop;

import com.connecture.bigbear.ancillary.rules.process.StatelessRuleExecutor;

public class StatelessEligibilityService extends AbstractEligibilityService {
	
	
	protected void doExecute(Object[] facts, boolean multiple) {
		String session = "StatelessShopKS"; 
		if(multiple){
			session = "MStatelessShopKS";
		}
		doExecute(facts, session); 
	}

	private void doExecute(Object[] facts, String session) {
		log.info(session+"@StatelessShopping execute Started ");
		try { 
			StatelessRuleExecutor executor = new StatelessRuleExecutor(session);
			super.setExecutor(executor);
			executor.setGlobal(getGlobal() );
			executor.execute(facts); 
		} catch (Exception e) { 
			log.error(session+"@StatelessShopping execute ", e);
		}
	}  
}
