package com.connecture.bigbear.ancillary.json.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class JsonReader {
	
public static String readJsonContent(String jsonPath) {
	File j = null; 
	FileInputStream fis = null;
	byte[] b = null;
	try {
		 j = new File(jsonPath);
		 fis = new FileInputStream(j);
		  b = new byte[fis.available()];
		 fis.read(b);
	} catch (FileNotFoundException e) { 
		e.printStackTrace();
	} catch (IOException e) { 
		e.printStackTrace();
	} finally{
		if(fis!=null){
			try {
				fis.close();
			} catch (IOException e) { 
				e.printStackTrace();
			}
		}
	}
	return new String(b); 
}

public static String readJsonContentFromClassPath(String jsonPath) {
	 
	byte[] b = null;
	InputStream is = JsonReader.class.getClassLoader().getResourceAsStream(jsonPath);
	try {
		 b = new byte[is.available()];
		 is.read(b);
	} catch (IOException e) { 
		e.printStackTrace();
	}
	return new String(b); 
}
 
 
}
