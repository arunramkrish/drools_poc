package com.connecture.bigbear.ancillary.session;

import org.kie.api.runtime.KieSession;

public class StatefulSession extends BaseSession{
	KieSession kSession =null;
	//TODO Need to analyze 
		//  thread-safe, 
		//  implement ThreadLocal
		//  RunTimeManager
	public StatefulSession() {
		
	}
	public KieSession getSession() { 
		kSession = kContainer.newKieSession(); 
	    kContainer.verify();
	    log.info("@getSession Return ");
	    return kSession; 
	} 
	public KieSession getSession(String name) { 
		kSession = kContainer.newKieSession(name); 
	    kContainer.verify();
	   
	    log.info("@getSession Return :"+name);
	    return kSession; 
	} 
	public void clean() {
		if(kSession!=null){
			kSession.dispose();  
		}
	}
	 
}
