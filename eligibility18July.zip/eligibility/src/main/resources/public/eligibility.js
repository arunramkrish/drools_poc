var profile;
var appContextUrl = '/eligibility';
var appHost = 'http://localhost:9000';
function prettifyJson(data) {
	return '<pre><code>' + JSON.stringify(data, null, 4) + '</code></pre>';
}

function showSummary(data) {
	var s='<pre><code>Summary:<br/>';
	if($.isArray(data)){
		s+=' Size : '+data.length+'<br/>';
	}
	s+='</code></pre>';
	return s;
}
function createProfileForm(formid, profile) { 
	
	var newDiv =  $('#'+formid); 
	var textArea = $('<textarea id="profilejson"/>'); 
	textArea.text(JSON.stringify(profile, null, 4) );
	newDiv.append(textArea); 
}

 
$(document).ready(function() {
	$("#request").hide();
	$("#response").hide();
	$('#errors').hide();
	$.getJSON(appHost+appContextUrl+"/profile/", function(l_profile) { 
		createProfileForm('profileForm', l_profile);
		profile = l_profile;
	});

	$("#profile").submit(function(e) {
		var in_profile = $('#profilejson').val(); 
		$("#resTable").show();
		$("#request").show();
		$("#request").html(prettifyJson(JSON.parse(in_profile)));
		$("#response").hide();
		$('#errors').hide();
		$('#loadingmessage').show();
		$.ajax({
			url : appContextUrl+"/plans/",
			type : "POST",
			cache : false,
			processData : false,
			data : in_profile,
			dataType : "json",
			timeout : 100000,
			contentType : "application/json; charset=utf-8",
			success : function(data) { 
				$('#loadingmessage').hide();
				$("#response").html(prettifyJson(data));
				$("#summary").html(showSummary(data));
				$("#summary").show();
				$("#response").show();
				$('#errors').hide();
			},
			error : function(xhr, status, error) {
				$('#loadingmessage').hide();
				$("#request").hide();
				$('#errors').html(xhr.responseText); 
				$("#summary").hide();
				$("#response").hide();
				$('#errors').show();
			},
			done : function(e) {
				$('#loadingmessage').hide();
				console.log(e);
			}
		});
		e.preventDefault();
	});
});
