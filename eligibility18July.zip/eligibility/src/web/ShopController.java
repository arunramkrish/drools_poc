package com.connecture.bigbear.ancillary.shop.web;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.model.Profile;
import com.connecture.bigbear.ancillary.shop.Shop;
import com.connecture.bigbear.ancillary.shop.StatelessShop;
import com.connecture.bigbear.ancillary.test.data.TestData;

@RestController
@EnableAutoConfiguration
public class ShopController {
	 @RequestMapping("/plans")
	 @ResponseBody
	Set<Plan> plans(@RequestParam("profile")Profile profile){
		 Object[]facts = null; 
			Set<Plan> recommended = null;
			Set<Plan> plans = TestData.getPlansObject();
			Shop s = new StatelessShop();
			facts = new Object[]{profile,plans};
			s.execute(facts,false);			
			recommended = new HashSet<Plan>();
			buildResult(s,recommended);
			profile.setRecommendedPlans(recommended); 
		return recommended;
	}
	 private void buildResult(Shop s, Set<Plan> recommended) {
			Map<Plan,String> resultMap = s.getPlanMap();
			Set<Plan> keys= resultMap.keySet();

			for (Iterator<Plan> iterator2 = keys.iterator(); iterator2.hasNext();) {
				Plan plan = (Plan) iterator2.next();
				String value = resultMap.get(plan);
				if(value!=null && value.startsWith("NO_MATCH"))
				{
					//log.view("Plan: "+plan+": "+value);
				} else {
					recommended.add(plan);
				}
			}
			
		}	
}
